package com.cognizant.epharma.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.cognizant.epharma.dao.MedicineDao;
import com.cognizant.epharma.model.Medicine;

@Service
@Component
public class MedicineService {
@Autowired
MedicineDao medDao;
	public void save(Medicine med) {
		
		medDao.save(med);
	}
	public Iterable<Medicine> findAll() {
		// TODO Auto-generated method stub
		return medDao.findAll();
	}
	public Iterable<Medicine> findAllExpired() {
		// TODO Auto-generated method stub
		return medDao.findAllExpired();
	}

}
