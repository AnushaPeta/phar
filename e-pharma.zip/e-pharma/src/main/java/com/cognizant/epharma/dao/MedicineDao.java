package com.cognizant.epharma.dao;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cognizant.epharma.model.Medicine;

public interface MedicineDao extends JpaRepository<Medicine, Serializable> {

	@Query(value = "SELECT * FROM medicine WHERE (CAST(exp_date as DATE) - CURDATE()) <0 ", nativeQuery = true)
	Iterable<Medicine> findAllExpired();

	
}
