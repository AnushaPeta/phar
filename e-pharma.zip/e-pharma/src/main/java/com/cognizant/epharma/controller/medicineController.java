package com.cognizant.epharma.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cognizant.epharma.model.Medicine;
import com.cognizant.epharma.service.MedicineService;

@Controller
@RequestMapping("/medicine")
public class medicineController {
	@Autowired
	MedicineService medService;

	@GetMapping("/addmedform")
	public String addMedPage(Model model) {
		model.addAttribute("med", new Medicine());
		
		return "addproduct";
		
	}
	
	@PostMapping("/addmed")
	public String addMedPage(@ModelAttribute("med") Medicine med,Model model) {
		medService.save(med);
		
		
		return "addproduct";
		
	}

	@GetMapping("/viewmed")
	public String viewMedPage(Model model , ModelMap modelMap) {
		modelMap.addAttribute("medicines", medService.findAll());
		model.addAttribute("msg", "All  Medicines");
		return "medlist";
		
	}
	
	@GetMapping("/expiredmed")
	public String viewExpMedPage(Model model , ModelMap modelMap) {
		model.addAttribute("msg", "Expired Medicines");
		modelMap.addAttribute("medicines", medService.findAllExpired());
		
		return "medlist";
		
	}
}
