package com.cognizant.epharma;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EPharmaApplication {

	public static void main(String[] args) {
		SpringApplication.run(EPharmaApplication.class, args);
	}

}
